#include<stdio.h>
#include"main.h"

int student_count()
{
	int count;
	printf("Enter student count: ");
	scanf("%d", &count);
	return count;
}
