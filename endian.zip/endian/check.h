struct endian
{
int data;
char *ch;
};

typedef struct endian e1;
void check_endian(e1 s1);