typedef struct char_array
{
	char ch;
}ch_arr;

void print_char(ch_arr *s1);
void sort(ch_arr *s1);

#define size 5
